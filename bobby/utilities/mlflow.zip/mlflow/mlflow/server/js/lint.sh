#!/usr/bin/env bash
./node_modules/.bin/eslint src
