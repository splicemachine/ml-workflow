export const MLFLOW_INTERNAL_PREFIX = 'mlflow.';

